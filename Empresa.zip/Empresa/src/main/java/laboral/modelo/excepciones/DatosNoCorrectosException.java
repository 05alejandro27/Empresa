package laboral.modelo.excepciones;

public class DatosNoCorrectosException extends Exception{
    public DatosNoCorrectosException(String m) {
        super(m);
    }
}
